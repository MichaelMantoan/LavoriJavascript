var nome, cognome, luogoNascita, giornoNascita, meseNascita, annoNascita, genere;
    
var modalNome = document.getElementById("modal-nome");
var modalCognome = document.getElementById("modal-cognome");
var modalLuogoNascita = document.getElementById("modal-luogo-nascita");
var modalGiornoNascita = document.getElementById("modal-giorno-nascita");
var modalMeseNascita = document.getElementById("modal-mese-nascita");
var modalAnnoNascita = document.getElementById("modal-anno-nascita");
var modalGenere = document.getElementById("modal-genere");

var btnNome = document.getElementById("btn-nome");
var btnCognome = document.getElementById("btn-cognome");
var btnLuogoNascita = document.getElementById("btn-luogo-nascita");
var btnGiornoNascita = document.getElementById("btn-giorno-nascita");
var btnMeseNascita = document.getElementById("btn-mese-nascita");
var btnAnnoNascita = document.getElementById("btn-anno-nascita");
var btnGenere = document.getElementById("btn-genere");

var risultatoDiv = document.getElementById("risultato");

btnNome.onclick = function() {
  nome = document.getElementById("input-nome").value;
  modalNome.style.display = "none";
  modalCognome.style.display = "block";
}

btnCognome.onclick = function() {
  cognome = document.getElementById("input-cognome").value;
  modalCognome.style.display = "none";
  modalLuogoNascita.style.display = "block";
}

btnLuogoNascita.onclick = function() {
  luogoNascita = document.getElementById("input-luogo-nascita").value;
  modalLuogoNascita.style.display = "none";
  modalGiornoNascita.style.display = "block";
}

btnGiornoNascita.onclick = function() {
  giornoNascita = document.getElementById("input-giorno-nascita").value;
  modalGiornoNascita.style.display = "none";
  modalMeseNascita.style.display = "block";
}

btnMeseNascita.onclick = function() {
  meseNascita = document.getElementById("input-mese-nascita").value;
  modalMeseNascita.style.display = "none";
  modalAnnoNascita.style.display = "block";
}

btnAnnoNascita.onclick = function() {
  annoNascita = document.getElementById("input-anno-nascita").value;
  modalAnnoNascita.style.display = "none";
  modalGenere.style.display = "block";
}

btnGenere.onclick = function() {
  genere = document.getElementById("input-genere").value.toUpperCase();
  modalGenere.style.display = "none";
  
  var codiceFiscale = calcolaCodiceFiscale(nome, cognome, luogoNascita, giornoNascita, meseNascita, annoNascita, genere);
  risultatoDiv.textContent = "Il tuo codice fiscale semplificato è: " + codiceFiscale;
}

function calcolaCodiceFiscale(nome, cognome, luogoNascita, giornoNascita, meseNascita, annoNascita, genere) {
  // Converte il nome e il cognome in maiuscolo
  nome = nome.toUpperCase();
  cognome = cognome.toUpperCase();

  // Rimuove gli spazi all'interno del nome e cognome
  nome = nome.replace(/\s/g, '');
  cognome = cognome.replace(/\s/g, '');

  // Prende le prime tre lettere del nome e cognome
  var primeTreLettereNome = nome.substring(0, 3);
  var primeTreLettereCognome = cognome.substring(0, 3);

  // Concatena i numeri di giorno, mese e anno di nascita
  var dataNascita = giornoNascita.padStart(2, '0') + meseNascita.padStart(2, '0') + annoNascita.substring(2, 4);

  // Prende le prime tre lettere del luogo di nascita
  var primeTreLettereLuogoNascita = luogoNascita.substring(0, 3);

  // Concatena il genere (F per femmina, M per maschio)
  var carattereGenere = genere === "F" ? "F" : "M";

  // Concatena tutte le parti per formare il codice fiscale
  var codiceFiscale = primeTreLettereCognome + primeTreLettereNome + dataNascita + primeTreLettereLuogoNascita + carattereGenere;

  return codiceFiscale;
}